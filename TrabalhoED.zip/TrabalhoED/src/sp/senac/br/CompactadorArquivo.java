/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sp.senac.br;

/**
 *
 * @author Sara
 */
public class CompactadorArquivo {
     public static String compactaFrase(String frase){
        frase = "Que que que, isso é uma coisa boa, muito boa";
        
        //Criacao da lista encadeada para armazenar as palavras do texto
        EncadeadaLista fraseArmazenada = new EncadeadaLista();
        
        //Criacao da lista encadeada para armazenar as palavras do texto compactadas
        EncadeadaLista fraseCompactada = new EncadeadaLista();
        
        //Separa o texto em palavras e armazena em um vetor de String, utilizando regex
        String [] palavras = frase.split("(?<=\\b|[^\\p{L}])");
        
        //Adiciona todas as palavras do vetor em uma lista encadeada
        for (int i = 0; i < palavras.length; i++) {            
            fraseArmazenada.comeco(palavras[i]);
        }
        
        /*Percorre a lista de palavras do texto e adiciona em uma lista de palavras compactadas, caso essa palavra já esteja na lista compactada, ela adiciona a referencia (posicao)
        na lista compactada*/
        for(int i = 0; i<fraseArmazenada.NoCount(); i++){
            String palavra = fraseArmazenada.getIndex(i);
          
            //Se for a segunda ou mais ocorrencia da mesma palavra, será adicionado a lista compactada a referencia (posicao) da primeira vez que essa palavra apareceu
            if(fraseCompactada.buscaLinearR(palavra) && !palavra.equals(",") && !palavra.equals(" ") && !palavra.equals(".")){
                fraseCompactada.comeco(Integer.toString(i));
            }
            //Se for a primeira ocorrencia da palavra na lista, adiciona esta na lista
            else{
                fraseCompactada.comeco(palavra);
            }
        }
        
        //System.out.println(textoCompactado.toString());  
        return fraseCompactada.toString();
     }       
     
        public static void descompactaFrase (String textoComp) {

        EncadeadaLista textoDescompactado = new EncadeadaLista();
        EncadeadaLista listaCompactada = new EncadeadaLista();

        String[] palavrasC = textoComp.split("(?<=\\b|[^\\p{L}])");
        
        for (int i = 0; i < palavrasC.length; i++) {
            listaCompactada.comeco(palavrasC[i]);
        }

        for (int i = 0; i < listaCompactada.NoCount(); i++) {
            if (listaCompactada.getIndex(i).matches("\\d+")) {
                int pos = Integer.parseInt(listaCompactada.getIndex(i));
                textoDescompactado.comeco(palavrasC[pos]);
            } else {
                textoDescompactado.comeco(palavrasC[i]);
            }
        }

        System.out.println(textoDescompactado.toString());

    }

    public static void main(String[] args) {
        
        compactaFrase("Que que, isso é uma coisa boa, muito boa");


    }
        
}
