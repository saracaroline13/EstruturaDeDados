/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sp.senac.br;

/**
 *
 * @author Sara
 */
public class EncadeadaLista {
    
    private NoLista ini;
    
    //Criar uma lista vazia
    public EncadeadaLista(){
        this.ini = null;
    }
   //Verifica se  lista está vazia
    public boolean isEmpty(){
        return this.ini == null;
    }
    
    public void comeco (String elemento){
        NoLista novo = new NoLista (elemento, ini);
        ini = novo;
    }
    

    @Override
    public String toString() {
        String strLista = "";
        NoLista temp = ini;
        
        while( temp != null){
            strLista = strLista + temp.getElemento() + " ";
            temp = temp.getProx();
        }
        return strLista;
    }
    public String getIndex (int x){
        NoLista temp = ini;
        
        String object = new String();
        
        for(int i =0; i <= x; i++){
            if(temp.getElemento() != null){
                object = temp.getElemento();
                temp = temp.getProx();
            }
            else{
                return null;
            }
        }
        
        return object;
    }

     
      public boolean buscaLinearR(String x){
          return buscaLinearR(ini, x);
      }
      public boolean buscaLinearR(NoLista temp, String x){
          
          if(temp == null){
              return false;
          }
          
          if (temp.getElemento().equals(x)){
              return true;
          }
          
          return buscaLinearR(temp.getProx(), x);
      }
//      
      
      public void removeInicio(){
          if(isEmpty()){
              System.out.println("Lista vazia!");
              return;
          }
          //A lista possui ao menos um nó, remover esse primeiro nó
          ini = ini.getProx();
      }
      public void removeFinal(){
         if(isEmpty()){
              System.out.println("Lista vazia!");
              return;
          } 
         NoLista temp = ini;
         NoLista anterior = null;
         
         while (temp.getProx() != null){
             anterior = temp;
             temp = temp.getProx();
         }
         //Apenas um nó
         if(anterior == null){
             ini = null; //lista vazia
             return;
         }  
         //Lista com dois ou mais nós
         anterior.setProx(null);
      }
      public void removeFinalR(){
          removeFinalR(null, ini);
      }
      public void removeFinalR(NoLista anterior, NoLista temp){
          if(isEmpty()){
              System.out.println("Lista vazia!");
              return;
          }
          //Está no primeiro e único nó
         if(anterior == null && temp.getProx() == null){
             ini = null; //lista vazia
             return;
         }
         //Está no último nó
         if(temp.getProx() == null){
            anterior.setProx(null);
            return;
         }
         removeFinalR(temp,temp.getProx());
      }
      public void removeFinal2(){
         if(isEmpty()){
              System.out.println("Lista vazia!");
              return;
          } 
         NoLista temp = ini;
         
         //Parar no penúltimo nó
         while (temp.getProx().getProx() != null){
             temp = temp.getProx();
         }
         //Apenas um nó
         if(temp.getProx() == null){
             ini = null; //lista vazia
             return;
         }  
         //Lista com dois ou mais nós
         temp.setProx(null);
      }
      public void removeFinalR2(){
          removeFinalR2(ini);
      }
      public void removeFinalR2(NoLista temp){
          if(isEmpty()){
              System.out.println("Lista vazia!");
              return;
          }
          //Está no primeiro e único nó
         if(temp.getProx() == null){
             ini = null; //lista vazia
             return;
         }
         //Está no último nó
         if(temp.getProx().getProx() == null){
            temp.setProx(null);
            return;
         }
         removeFinalR2(temp.getProx());
      }
      
//      
      public int NoCount(){
          NoLista temp = ini;
          int cont = 0;
          
          while (temp != null){
              temp = temp.getProx();
              cont++;
          }
          return cont;
      }
      public int NoCount2(){
          int cont = 0;

          for(NoLista temp=ini; temp != null; temp=temp.getProx()){
              cont++;
          }
          return cont;
      }
    }
    
