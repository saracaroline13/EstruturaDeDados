/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sp.senac.br;

/**
 *
 * @author Sara
 */
public class NoLista {
    private String elemento;
    private NoLista prox;

    //Cria um nó
    public NoLista(String elemento, NoLista prox) {
        this.elemento = elemento;
        this.prox = prox;
    }

    public String getElemento() {
        return elemento;
    }

    public NoLista getProx() {
        return prox;
    }

    public void setElemento(String elemento) {
        this.elemento = elemento;
    }

    public void setProx(NoLista prox) {
        this.prox = prox;
    }

    @Override
    public String toString() {
        return "No{" + "elemento=" + elemento + ", prox=" + prox + '}';
    }
}
